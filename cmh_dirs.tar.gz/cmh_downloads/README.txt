Directory where administrative tasks should place their downloads. From here, the these files may be un-zipped, un-tar'ed, copied, etc.
