Directory used to store various log files created during administrative tasks
