Directory that contain descriptions and perhaps xml files for various HS events.- initial CMH event set-up
(need to figure out how to merge these events with others that are created especially for a particular customer setup)
