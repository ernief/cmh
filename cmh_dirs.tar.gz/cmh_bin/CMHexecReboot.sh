#!/bin/bash
# CMHexecReboot.sh
#
# Part of a graceful HS3 shutdown and HS3 restart (via a system reboot) procedure
#
# This script is called from HS event
# Records the restart in a log file

REBOOT_LOC=/home/homeseer/cmh_bin
LOG_DIR=/home/homeseer/cmh_logs
exec ${REBOOT_LOC}/CMHReboot.sh > ${LOG_DIR}/CMHReboot.log
