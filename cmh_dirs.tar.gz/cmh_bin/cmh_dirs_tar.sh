#!/bin/bash
# create a tar file of the CMH custom files
cd /home/homeseer
tar -cvzf cmh_dirs.tar.gz ./cmh_*
