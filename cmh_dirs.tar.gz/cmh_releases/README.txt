Directory used to store software releases.
These could include:
- HS3 release zip files
- CMH zip or tar files
