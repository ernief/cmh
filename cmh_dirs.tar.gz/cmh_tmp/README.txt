directory for temporary storage of files. Everything in here can be removed periodically.
