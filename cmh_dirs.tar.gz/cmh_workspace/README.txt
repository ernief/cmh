Directory used during the creation and debug of various scripts, etc.
