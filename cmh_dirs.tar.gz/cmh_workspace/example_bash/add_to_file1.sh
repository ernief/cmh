#!/bin/bash
cat >>file1 <<EOM
-------------------------
this should be appended to file1
we will see
EOM
