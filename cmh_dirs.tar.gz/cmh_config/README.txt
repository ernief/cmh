Directory for configuring various maintenance tasks
- list of system files customized for CMH/HomeSeer adiministrative purposes
