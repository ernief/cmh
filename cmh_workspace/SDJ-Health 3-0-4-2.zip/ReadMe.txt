To install
copy program file:
'HSPI_SDJ-Health.exe' to the HS3 root folder '//HomeSeer HS3'
copy images folder:
'SDJ-Health' to '//Homeseer HS3/html/images/'

To completely uninstall:
Remove program file: 'HSPI_SDJ-Health.exe'
Remove images folder '//Homeseer HS3/html/images/SDJ-Health'
Remove config file '//HomeSeer HS3/Config/SDJ-Health.ini'